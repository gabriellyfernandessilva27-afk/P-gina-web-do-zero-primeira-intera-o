// Sistema de curtidas: somente os botões com a classe .btn-curtir.
const botoesCurtir = document.querySelectorAll(".btn-curtir");

botoesCurtir.forEach(function (botao) {
    let curtiu = false;

    botao.addEventListener("click", function () {
        const contador = botao.querySelector("span");
        const valorAtual = parseInt(contador.textContent, 10);

        if (!curtiu) {
            contador.textContent = valorAtual + 1;
            curtiu = true;
        } else {
            contador.textContent = valorAtual - 1;
            curtiu = false;
        }
    });
});

// Alternância entre modo claro e modo escuro.
const themeToggleBtn = document.getElementById("theme-toggle");

if (themeToggleBtn) {
    themeToggleBtn.addEventListener("click", function () {
        document.body.classList.toggle("dark-mode");
    });
}

// Botão de conclusão: não altera o contador de curtidas.
const botaoZerado = document.getElementById("btn-zerado");

if (botaoZerado) {
    botaoZerado.addEventListener("click", function () {
        botaoZerado.classList.toggle("concluido");
        botaoZerado.setAttribute(
            "aria-pressed",
            botaoZerado.classList.contains("concluido")
        );
        botaoZerado.querySelector("span").textContent =
            botaoZerado.classList.contains("concluido") ? "✓" : "0";
    });
}
